"""
良知库 RAG · GCS-backed
=======================

冷启动流程：
  1. GCS 拉 corpus.json + manifest.json  (~50KB)
  2. GCS 拉 embeddings.npy             (~80KB / 24 段)
  3. 本地装 sentence-transformers 模型（已 baked 入 Docker 镜像，离线）
  4. 即可服务请求

若 embeddings.npy 不存在（如初次部署或 corpus 改动后未跑 precompute）：
  在容器内编码语料（~30s），首请求延迟严重。生产环境务必先跑 precompute。
"""
import os
from typing import List, Dict, Optional
import numpy as np

from gcs import GCSCorpusLoader


class CorpusRetriever:
    def __init__(self, bucket_name: str, version: str = "v1"):
        self.loader = GCSCorpusLoader(bucket_name, version)
        self.passages: List[Dict] = []
        self.embeddings: Optional[np.ndarray] = None
        self.model = None
        self.manifest: Dict = {}

    async def aload(self):
        # 1. corpus + manifest
        corpus = self.loader.load_corpus()
        self.passages = corpus["passages"]
        self.manifest = self.loader.load_manifest()

        # 2. precomputed embeddings (preferred)
        self.embeddings = self.loader.load_embeddings()

        # 3. encoding model (baked into image, offline at runtime)
        from sentence_transformers import SentenceTransformer
        model_name = self.manifest.get("model", "BAAI/bge-small-zh-v1.5")
        self.model = SentenceTransformer(model_name)

        # 4. fallback: compute on container if precompute hasn't run
        if self.embeddings is None:
            print("⚠ 预计算 embeddings 缺失 · 容器内编码（约 30s）", flush=True)
            self.embeddings = self.model.encode(
                [p["text"] for p in self.passages],
                normalize_embeddings=True,
                convert_to_numpy=True,
                show_progress_bar=False,
            )

    def search(self, query: str, k: int = 5) -> List[Dict]:
        if not self.passages or self.embeddings is None or self.model is None:
            return []
        q_vec = self.model.encode([query], normalize_embeddings=True)[0]
        scores = self.embeddings @ q_vec  # cosine since both normalized
        top_idx = np.argsort(scores)[::-1][:k]
        return [{**self.passages[i], "score": float(scores[i])} for i in top_idx]
