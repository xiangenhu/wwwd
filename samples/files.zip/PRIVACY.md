# 阳明何为 · 隐私白名单

> 「不传」之誓，不是抽象承诺，是可验之约。
> 此文件公开声明门户记录之一切。代码（`lrs.py`）以 `SAFE_RESULT_KEYS` 与 `ALLOWED_FRONTEND_EVENTS` 强制此白名单。两处不一致即为缺陷，请提 issue。

---

## 永远不录

```
✗ 用户输入之情境原文
✗ 模型生成之四阶输出原文
✗ 用户立志（行动承诺）之原文
✗ 用户回访自报之内容
✗ 真实姓名、邮箱、电话、IP 地址（非 actor 字段中）
✗ 浏览器精确指纹
```

## 必录（用以衡门户之效，非衡用户之心）

| 事件 (verb) | 时机 | 记 | 不记 |
|---|---|---|---|
| `began-deliberation` | 用户点「始问心」 | 情境长度（字数）、模式、字体、情境 hash | 情境原文 |
| `consulted-corpus` | RAG 检索完成 | 召回的语料 ID（公开 corpus 引用） | 检索分数与原文 |
| `completed-stage` | 一阶生成完毕 | 阶段编号、时长（秒）、输出字数 | 输出原文 |
| `completed-deliberation` | 全四阶完毕或中止 | 总时长、完成阶数 | — |
| `viewed-corpus` | 用户展开「引自传习录」 | 是否查看（boolean） | 哪一段 |
| `committed-action` | 用户标记某条行动「我立此志」 | 行动序号 (1–4)、是否含概念标签 | 行动原文 |
| `parted-ways` | 用户答「此事既明，可暂别」 | session 总数、距首访天数 | — |
| `declined-followup` | 用户辞 7 日回访 | 仅事件本身 | — |

## actor 字段之化名机制

所有事件中之 actor 形如：

```json
{
  "objectType": "Agent",
  "account": {
    "homePage": "https://wwwd.skoonline.org",
    "name": "google:7a3f8c…[32 字符]"
  }
}
```

化名生成：`sha256(SALT + google_user_sub)[:32]`

- `SALT` 为 32 字节随机值，存于 Secret Manager，**仅服务运行时可见**。
- 即便 actor 之 hash 公开，**无 SALT 不能反推**至 Google sub。
- 匿名模式（未登录）以 client UUID 替 google_sub，session 后即不可联接。

## 用户之自查

任何用户可：

1. 致函 contact@... 索取「关于我之 actor.id 的全部记录」；
2. 索要其全部记录之删除（GDPR / PIPL 等下之被遗忘权）；
3. 验证此文件之白名单与代码（`lrs.py`）一致。

---

> 此文件版本：v1.0 · 与 `lrs.py@0.2.0` 配套
> 任何对捕获字段之扩展，必先：(a) 改此文件；(b) 改 lrs.py；(c) 用户协议同步更新。三者不齐，部署不发。
