"""
阳明何为 · Cloud Run 后端
=========================

变化（vs 本地版）：
  + GCS 加载语料 + 预计算 embeddings
  + Google OAuth ID token 验证 (auth.get_actor)
  + xAPI 语句于关键节点发射 (lrs)
  + 端口 8080（Cloud Run 标准）
  - 本地 corpus 文件依赖移除
"""
import os
import json
import time
import asyncio
import uuid
from typing import Optional, AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from anthropic import AsyncAnthropic

from rag import CorpusRetriever
from prompts import build_stage_messages, STAGE_NAMES
from auth import Actor, get_actor
import lrs


# ============================================================
# Globals
# ============================================================
retriever: Optional[CorpusRetriever] = None
client: Optional[AsyncAnthropic] = None

DEFAULT_MODEL = os.environ.get("CLAUDE_MODEL", "claude-opus-4-5")
GCS_BUCKET = os.environ.get("WWWD_GCS_BUCKET")
CORPUS_VERSION = os.environ.get("WWWD_CORPUS_VERSION", "v1")


@asynccontextmanager
async def lifespan(app: FastAPI):
    global retriever, client

    print("=" * 60, flush=True)
    print("阳明何为 · Cloud Run 启动", flush=True)
    print(f"  GCS    · gs://{GCS_BUCKET}/corpus/{CORPUS_VERSION}/", flush=True)
    print(f"  Model  · {DEFAULT_MODEL}", flush=True)
    print("=" * 60, flush=True)

    if not GCS_BUCKET:
        raise RuntimeError("WWWD_GCS_BUCKET environment variable required")

    retriever = CorpusRetriever(GCS_BUCKET, CORPUS_VERSION)
    await retriever.aload()
    dim = retriever.embeddings.shape[1] if retriever.embeddings is not None else "?"
    print(f"语料 · {len(retriever.passages)} 段, dim={dim}", flush=True)

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise RuntimeError("ANTHROPIC_API_KEY required")
    client = AsyncAnthropic(api_key=api_key)

    print("门户已立", flush=True)
    yield
    print("门户关闭", flush=True)


app = FastAPI(
    title="阳明何为 · Cloud Run 后端",
    version="0.2.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.environ.get("CORS_ORIGINS", "*").split(","),
    allow_methods=["*"],
    # Authorization + X-Wwwd-Session must be allowed for actor resolution
    allow_headers=["Content-Type", "Authorization", "X-Wwwd-Session"],
)


# ============================================================
# Schemas
# ============================================================
class DeliberateRequest(BaseModel):
    scenario: str = Field(..., min_length=10, max_length=2000)
    mode: str = Field("standard")
    script: str = Field("cn")


class FrontendEventRequest(BaseModel):
    verb_key: str = Field(..., description="One of: viewed-corpus, committed-action, parted-ways, declined-followup")
    session_id: str
    result_ext: Optional[dict] = None


# ============================================================
# Endpoints
# ============================================================
@app.get("/api/health")
async def health():
    return {
        "status": "ok",
        "corpus_size": len(retriever.passages) if retriever else 0,
        "corpus_version": CORPUS_VERSION,
        "model": DEFAULT_MODEL,
        "auth": {
            "oauth_configured": bool(os.environ.get("GOOGLE_OAUTH_CLIENT_ID")),
            "require_auth": os.environ.get("WWWD_REQUIRE_AUTH", "0") == "1",
        },
    }


@app.post("/api/deliberate")
async def deliberate(req: DeliberateRequest, actor: Actor = Depends(get_actor)):
    if not retriever or not client:
        raise HTTPException(503, "Service not ready")

    session_id = str(uuid.uuid4())
    retrieved = retriever.search(req.scenario, k=8)

    # xAPI · session began (no scenario text in statement, only hash + length)
    lrs.began_deliberation(actor, req.scenario, req.mode, req.script, session_id)
    lrs.consulted_passages(actor, [p["id"] for p in retrieved], session_id)

    return StreamingResponse(
        _deliberation_stream(actor, session_id, req, retrieved),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
            "X-Wwwd-Session": session_id,  # exposed to frontend so subsequent
                                            # frontend events can correlate
        },
    )


@app.post("/api/xapi/event")
async def xapi_event(req: FrontendEventRequest, actor: Actor = Depends(get_actor)):
    """Frontend-emitted xAPI events. Whitelisted verbs & extension keys only."""
    stmt = lrs.frontend_event(
        actor=actor,
        verb_key=req.verb_key,
        session_id=req.session_id,
        result_ext=req.result_ext,
    )
    if stmt is None:
        raise HTTPException(400, f"Verb '{req.verb_key}' not in allowlist")
    return {"ok": True, "id": stmt["id"]}


# ============================================================
# Streaming generator
# ============================================================
def _sse(event: str, data: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(data, ensure_ascii=False)}\n\n"


async def _deliberation_stream(
    actor: Actor,
    session_id: str,
    req: DeliberateRequest,
    retrieved: list,
) -> AsyncGenerator[str, None]:
    deliberation_start = time.perf_counter()
    stages_completed = 0

    try:
        yield _sse("session", {"session_id": session_id})

        yield _sse("corpus", {
            "passages": [
                {"source": p["source"], "text": p["text"], "score": p.get("score", 0)}
                for p in retrieved
            ]
        })

        for stage_num in [1, 2, 3, 4]:
            stage_start = time.perf_counter()
            output_chars = 0

            yield _sse("stage_start", {"stage": stage_num, "name": STAGE_NAMES[stage_num]})

            messages = build_stage_messages(
                stage=stage_num,
                scenario=req.scenario,
                retrieved=retrieved,
                mode=req.mode,
                script=req.script,
            )

            async with client.messages.stream(
                model=DEFAULT_MODEL,
                max_tokens=1024,
                system=messages["system"],
                messages=messages["messages"],
            ) as stream:
                async for text in stream.text_stream:
                    output_chars += len(text)
                    yield _sse("stage_chunk", {"stage": stage_num, "text": text})

            stage_duration_ms = int((time.perf_counter() - stage_start) * 1000)
            lrs.completed_stage(
                actor, stage_num, STAGE_NAMES[stage_num],
                stage_duration_ms, output_chars, session_id,
            )
            yield _sse("stage_end", {"stage": stage_num})
            stages_completed += 1
            await asyncio.sleep(0.05)

        total_ms = int((time.perf_counter() - deliberation_start) * 1000)
        lrs.completed_deliberation(actor, total_ms, stages_completed, session_id)
        yield _sse("complete", {"message": "问心已成"})

    except Exception as e:
        total_ms = int((time.perf_counter() - deliberation_start) * 1000)
        lrs.completed_deliberation(actor, total_ms, stages_completed, session_id)
        yield _sse("error", {"message": str(e), "stage": stages_completed + 1})


if __name__ == "__main__":
    import uvicorn
    port = int(os.environ.get("PORT", 8080))  # Cloud Run injects PORT
    uvicorn.run("server:app", host="0.0.0.0", port=port)
