"""
xAPI 语句构造 + 发射器
======================

阶段 1（当前）: emit 至 stdout (Python logger "xapi")。
  Cloud Run 自动捕获至 Cloud Logging。
  以 jsonPayload.kind="xapi" 过滤；
  日志路由（Logging Sink）→ BigQuery 或 Pub/Sub → 后期接入真实 LRS。

阶段 2（后期）: 改 _emit() 一处，POST 至 LRS endpoint，签名 Basic Auth。
  接口稳定，调用方代码无变更。

【「不传」之实践 · 此模块对 PII 的硬约束】
  ✓ 记录: actor 化名 hash, verb, 阶段编号, 时长, 词数, 语料 ID, 行动序号
  ✗ 不录: 用户情境原文, 模型输出原文, 用户立志原文, 自报变化原文, 原始姓名邮箱

  详见 PRIVACY.md 之公开白名单。
"""
import os
import json
import logging
import hashlib
import uuid
from datetime import datetime, timezone
from typing import Optional, List

from auth import Actor

# ============================================================
# Logger (stdout → Cloud Logging on Cloud Run)
# ============================================================
xapi_logger = logging.getLogger("xapi")
xapi_logger.setLevel(logging.INFO)
if not xapi_logger.handlers:
    h = logging.StreamHandler()
    h.setFormatter(logging.Formatter("%(message)s"))
    xapi_logger.addHandler(h)
    xapi_logger.propagate = False

VERB_BASE = os.environ.get("WWWD_VERB_BASE", "https://wwwd.skoonline.org/verbs")
ACTIVITY_BASE = os.environ.get("WWWD_ACTIVITY_BASE", "https://wwwd.skoonline.org/activities")
PLATFORM = "wwwd-portal"


# ============================================================
# Helpers
# ============================================================
def _now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _statement_id() -> str:
    return str(uuid.uuid4())


def _scenario_hash(text: str) -> str:
    """Hash for activity ID. Not reversible. Same hash → same scenario asked twice."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def _emit(stmt: dict):
    """The single point of egress. Swap to LRS POST here when ready."""
    xapi_logger.info(json.dumps({"kind": "xapi", "statement": stmt}, ensure_ascii=False))


def _ext(d: dict) -> dict:
    """Wrap extension dict with required full-IRI keys."""
    return {f"{ACTIVITY_BASE}/ext/{k}": v for k, v in d.items()}


def _ctx(session_id: str, **extra) -> dict:
    return {
        "platform": PLATFORM,
        "extensions": _ext({"session-id": session_id, **extra}),
    }


# ============================================================
# Statement builders (ALL strip PII)
# ============================================================

def began_deliberation(actor: Actor, scenario: str, mode: str, script: str, session_id: str) -> dict:
    """User started a four-stage deliberation. Captures: hash + length + meta."""
    stmt = {
        "id": _statement_id(),
        "actor": actor.to_xapi(),
        "verb": {
            "id": f"{VERB_BASE}/began-deliberation",
            "display": {"zh-CN": "始问心", "en-US": "began deliberation"},
        },
        "object": {
            "id": f"{ACTIVITY_BASE}/scenario/{_scenario_hash(scenario)}",
            "objectType": "Activity",
            "definition": {
                "type": f"{ACTIVITY_BASE}/types/scenario",
                "name": {"zh-CN": "情境（隐名）", "en-US": "Scenario (pseudonymous)"},
            },
        },
        "result": {
            "extensions": _ext({
                "scenario-length": len(scenario),
                "mode": mode,
                "script": script,
            }),
        },
        "timestamp": _now(),
        "context": _ctx(session_id),
    }
    _emit(stmt)
    return stmt


def consulted_passages(actor: Actor, passage_ids: List[str], session_id: str) -> dict:
    """Which 传习录 passages were retrieved. Passage IDs are public corpus refs."""
    stmt = {
        "id": _statement_id(),
        "actor": actor.to_xapi(),
        "verb": {
            "id": f"{VERB_BASE}/consulted-corpus",
            "display": {"zh-CN": "稽诸传习录", "en-US": "consulted corpus"},
        },
        "object": {
            "id": f"{ACTIVITY_BASE}/corpus/chuanxilu",
            "objectType": "Activity",
        },
        "result": {"extensions": _ext({"passage-ids": passage_ids})},
        "timestamp": _now(),
        "context": _ctx(session_id),
    }
    _emit(stmt)
    return stmt


def completed_stage(actor: Actor, stage: int, stage_name: str,
                    duration_ms: int, output_char_count: int, session_id: str) -> dict:
    stmt = {
        "id": _statement_id(),
        "actor": actor.to_xapi(),
        "verb": {
            "id": f"{VERB_BASE}/completed-stage",
            "display": {"zh-CN": "成一阶", "en-US": "completed stage"},
        },
        "object": {
            "id": f"{ACTIVITY_BASE}/stage/{stage}",
            "objectType": "Activity",
            "definition": {
                "name": {"zh-CN": stage_name},
                "type": f"{ACTIVITY_BASE}/types/deliberation-stage",
            },
        },
        "result": {
            "duration": f"PT{duration_ms / 1000:.2f}S",
            "extensions": _ext({
                "output-char-count": output_char_count,
                "stage-num": stage,
            }),
        },
        "timestamp": _now(),
        "context": _ctx(session_id),
    }
    _emit(stmt)
    return stmt


def completed_deliberation(actor: Actor, total_duration_ms: int,
                           stages_completed: int, session_id: str) -> dict:
    stmt = {
        "id": _statement_id(),
        "actor": actor.to_xapi(),
        "verb": {
            "id": f"{VERB_BASE}/completed-deliberation",
            "display": {"zh-CN": "问心已成", "en-US": "completed deliberation"},
        },
        "object": {
            "id": f"{ACTIVITY_BASE}/deliberation",
            "objectType": "Activity",
        },
        "result": {
            "completion": stages_completed == 4,
            "duration": f"PT{total_duration_ms / 1000:.2f}S",
            "extensions": _ext({"stages-completed": stages_completed}),
        },
        "timestamp": _now(),
        "context": _ctx(session_id),
    }
    _emit(stmt)
    return stmt


# ============================================================
# Frontend-emitted events (POSTed to /api/xapi/event)
# These ALSO strip PII server-side, regardless of what client sent.
# ============================================================

ALLOWED_FRONTEND_EVENTS = {
    "viewed-corpus": {"display": {"zh-CN": "观语料", "en-US": "viewed corpus"}},
    "committed-action": {"display": {"zh-CN": "立志", "en-US": "committed action"}},
    "parted-ways": {"display": {"zh-CN": "暂别", "en-US": "parted ways"}},
    "declined-followup": {"display": {"zh-CN": "辞回访", "en-US": "declined follow-up"}},
}

# Whitelist of result.extensions keys the frontend may send.
# Anything else is silently dropped — even if client tries to send it.
SAFE_RESULT_KEYS = {
    "action-index",       # 1, 2, 3, or 4
    "has-concept-tag",    # boolean
    "session-count",      # integer
    "days-since-first",   # integer
    "scrolled-to-bottom", # boolean
}


def frontend_event(actor: Actor, verb_key: str, session_id: str,
                   result_ext: Optional[dict] = None) -> Optional[dict]:
    """Emit a frontend-originated event. Returns None if verb_key not allowed."""
    if verb_key not in ALLOWED_FRONTEND_EVENTS:
        return None
    safe_ext = {}
    if result_ext:
        for k, v in result_ext.items():
            if k in SAFE_RESULT_KEYS:
                safe_ext[k] = v
    stmt = {
        "id": _statement_id(),
        "actor": actor.to_xapi(),
        "verb": {
            "id": f"{VERB_BASE}/{verb_key}",
            "display": ALLOWED_FRONTEND_EVENTS[verb_key]["display"],
        },
        "object": {
            "id": f"{ACTIVITY_BASE}/portal",
            "objectType": "Activity",
        },
        "result": {"extensions": _ext(safe_ext)} if safe_ext else {},
        "timestamp": _now(),
        "context": _ctx(session_id),
    }
    _emit(stmt)
    return stmt
