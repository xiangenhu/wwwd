# 阳明何为 · Cloud Run 部署指南

> 本指南假定你有 GCP 项目、`gcloud` CLI、且具 Owner 或 Editor 权限。

## 摘要

```
[ 浏览器 ]
    │ HTTPS · Authorization: Bearer <Google ID token> 或 X-Wwwd-Session: <UUID>
    ▼
[ Cloud Run · wwwd-backend ]
    │
    ├──► [ GCS Bucket · wwwd-corpus ]   预计算 embeddings + corpus
    ├──► [ Anthropic API ]              Claude streaming
    ├──► [ Secret Manager ]             API key, actor salt
    └──► [ Cloud Logging ]              xAPI statements (kind="xapi")
              │
              └──► [ BigQuery sink ]   后期分析
              └──► [ 真实 LRS ]       后期接入 (改 lrs._emit() 一处)
```

---

## 一次性 GCP 配置

### 1. 启用 API

```bash
gcloud services enable \
  run.googleapis.com \
  cloudbuild.googleapis.com \
  artifactregistry.googleapis.com \
  storage.googleapis.com \
  secretmanager.googleapis.com \
  logging.googleapis.com
```

### 2. 创 Artifact Registry repo

```bash
REGION=asia-east1
gcloud artifacts repositories create wwwd \
  --location=$REGION \
  --repository-format=docker \
  --description="阳明何为 · 容器镜像"
```

### 3. 创 GCS bucket

```bash
PROJECT_ID=$(gcloud config get-value project)
BUCKET=wwwd-corpus  # 或加 PROJECT_ID 后缀以保唯一

gsutil mb -l asia-east1 -b on gs://$BUCKET

# 可选：bucket 级保留策略，防误删
gsutil retention set 30d gs://$BUCKET
```

### 4. 创 service account (运行时身份)

```bash
gcloud iam service-accounts create wwwd-runtime \
  --display-name="WWWD Cloud Run runtime"

# 仅授其读 GCS、写日志、读 Secret 之权
gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:wwwd-runtime@$PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/storage.objectViewer"

gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:wwwd-runtime@$PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/logging.logWriter"

gcloud projects add-iam-policy-binding $PROJECT_ID \
  --member="serviceAccount:wwwd-runtime@$PROJECT_ID.iam.gserviceaccount.com" \
  --role="roles/secretmanager.secretAccessor"
```

### 5. 存秘密

```bash
# Anthropic API key
echo -n 'sk-ant-XXXX' | \
  gcloud secrets create anthropic-api-key --data-file=-

# Actor hash salt（一旦设定不可改 · 改则历史 actor.id 全部失联）
openssl rand -hex 32 | \
  gcloud secrets create wwwd-actor-salt --data-file=-
```

### 6. (可选) 设 Google OAuth

若打算让用户登录以获稳定 actor.id：

1. 访 [Google Cloud Console · OAuth consent screen](https://console.cloud.google.com/apis/credentials/consent) 配应用。
2. 创 OAuth 2.0 Client ID（type: Web application）。
3. Authorized JavaScript origins: 你的前端域名（如 `https://wwwd.skoonline.org`）。
4. 记下 Client ID。下一步 substitutions 中用之。

---

## 跑预计算

每次 corpus.json 改动皆须跑此步，**且 bump version**（如 v1 → v2）。

```bash
cd wwwd-backend

# 本地装预计算所需依赖
pip install sentence-transformers google-cloud-storage numpy

# 用你账户的 application-default credentials
gcloud auth application-default login

# 跑
python precompute_embeddings.py \
  --corpus corpus.json \
  --bucket wwwd-corpus \
  --version v1
```

输出：
```
gs://wwwd-corpus/corpus/v1/corpus.json
gs://wwwd-corpus/corpus/v1/embeddings.npy
gs://wwwd-corpus/corpus/v1/manifest.json
```

---

## 部署

### 选项 A · 手动一次性

```bash
cd wwwd-backend

gcloud builds submit \
  --config=cloudbuild.yaml \
  --substitutions=_GCS_BUCKET=wwwd-corpus,_CORPUS_VERSION=v1,_GOOGLE_OAUTH_CLIENT_ID=YOUR_CLIENT_ID
```

### 选项 B · 自动（CI/CD）

GitHub / GitLab → Cloud Build trigger:

```bash
gcloud builds triggers create github \
  --name=wwwd-backend-deploy \
  --repo-name=YOUR_REPO \
  --repo-owner=YOUR_OWNER \
  --branch-pattern=^main$ \
  --build-config=wwwd-backend/cloudbuild.yaml
```

### 部署后

```bash
SERVICE_URL=$(gcloud run services describe wwwd-backend \
  --region=asia-east1 --format='value(status.url)')

echo "API: $SERVICE_URL"
curl $SERVICE_URL/api/health
```

期望返：
```json
{
  "status": "ok",
  "corpus_size": 24,
  "corpus_version": "v1",
  "model": "claude-opus-4-5",
  "auth": {"oauth_configured": true, "require_auth": false}
}
```

---

## 冷启动策略 · 三选

| 场景 | 月 PV 估 | 设置 | 月成本估* | 首请求延迟 |
|---|---|---|---|---|
| 验证 / 演示 / 学术分享 | < 1k | `min-instances=0` + 预计算 | $0 – $5 | ~8s |
| 早期生产 / 课程使用 | 1k – 50k | `min-instances=1` 工作时段** | $30 – $60 | ~200ms (warm) |
| 高流量 | > 50k | `min-instances=2` 全天 | $100+ | ~200ms |

\* 假定每请求约 0.5 vCPU·s + 0.3 GB·s + Anthropic 调用额外计费
\** 用 Cloud Scheduler + Cloud Run admin 在工作时段调 min-instances，下班归零

**当前默认是选项 1**（`_MIN_INSTANCES: '0'`）。修改：

```bash
gcloud run services update wwwd-backend \
  --region=asia-east1 \
  --min-instances=1
```

---

## 前端连后端

前端 v4 已支持 `?api=https://...` URL 参数与 `window.WWWD_BACKEND_URL` 全局变量。

**最简方式**：在前端 HTML `<head>` 末尾加：
```html
<script>
  window.WWWD_BACKEND_URL = "https://wwwd-backend-xxxxx-de.a.run.app";
  window.WWWD_GOOGLE_CLIENT_ID = "YOUR_CLIENT_ID.apps.googleusercontent.com";
</script>
```

**生产方式**：用自定义域 + Cloud Run domain mapping，前端 `BACKEND_URL` 默认即指向之。

---

## CORS 收紧

部署时务必将 `_CORS_ORIGINS` 改为前端实际域名：

```bash
gcloud run services update wwwd-backend \
  --region=asia-east1 \
  --set-env-vars=CORS_ORIGINS=https://wwwd.skoonline.org
```

---

## xAPI 日志查看

实时：
```bash
gcloud logging tail "jsonPayload.kind=xapi AND resource.type=cloud_run_revision"
```

历史：
```bash
gcloud logging read "jsonPayload.kind=xapi" --limit=50 --format=json
```

### 路由至 BigQuery（后期分析）

```bash
# 创 BigQuery dataset
bq mk wwwd_xapi

# 创 logging sink
gcloud logging sinks create wwwd-xapi-sink \
  bigquery.googleapis.com/projects/$PROJECT_ID/datasets/wwwd_xapi \
  --log-filter='jsonPayload.kind="xapi"'

# 授 sink writer 权限
SINK_SA=$(gcloud logging sinks describe wwwd-xapi-sink --format='value(writerIdentity)')
bq add-iam-policy-binding \
  --member=$SINK_SA \
  --role=roles/bigquery.dataEditor \
  $PROJECT_ID:wwwd_xapi
```

后续 BigQuery 中可 SQL 查询所有 xAPI statements。

### 后期接入真实 LRS

只改 `lrs.py` 中 `_emit()` 函数：

```python
import httpx
LRS_ENDPOINT = os.environ.get("LRS_ENDPOINT")
LRS_AUTH     = os.environ.get("LRS_BASIC_AUTH")

def _emit(stmt: dict):
    xapi_logger.info(json.dumps({"kind": "xapi", "statement": stmt}, ensure_ascii=False))
    if LRS_ENDPOINT:
        # fire-and-forget; don't block deliberation on LRS latency
        httpx.post(
            f"{LRS_ENDPOINT}/statements",
            json=[stmt],
            headers={
                "Authorization": f"Basic {LRS_AUTH}",
                "X-Experience-API-Version": "1.0.3",
            },
            timeout=2.0,
        )
```

---

## 常见问题

**Q. 容器启动失败，logs 显示 `WWWD_GCS_BUCKET environment variable required`**
A. 漏设环境变量。重跑 cloudbuild 时确保 `--substitutions=_GCS_BUCKET=...` 给到。

**Q. 健康检查通过但 `/api/deliberate` 返 503**
A. 多半是 GCS embeddings.npy 缺失。先跑 precompute_embeddings.py。

**Q. 流式输出在 Cloud Run 卡住**
A. 检查响应是否设了 `X-Accel-Buffering: no`（已含于代码）。再确认 Cloud Run timeout ≥ 60s（部署默认 600s）。

**Q. OAuth ID token 验证失败**
A. 检查 `GOOGLE_OAUTH_CLIENT_ID` 与前端 client_id 一致。`google-auth` 库会同时验证 token 的 `aud` 字段。

**Q. 想本地开发 + Cloud Run 部署同代码？**
A. 仍可。本地 `gcloud auth application-default login` 后，server.py 不变。GCS 客户端会自动用 ADC。

---

## 安全审计清单 · 部署前

- [ ] `WWWD_ACTOR_SALT` 已设为 32 字节随机值，存于 Secret Manager
- [ ] `ANTHROPIC_API_KEY` 存于 Secret Manager（**不在 cloudbuild.yaml 明文中**）
- [ ] `CORS_ORIGINS` 收紧至已知前端域名（**非 `*`**）
- [ ] Cloud Run service account 仅持最小权限（仅 storage.objectViewer，非 storage.admin）
- [ ] GCS bucket 禁公开访问（默认即如此，再确认一次）
- [ ] `_MIN_INSTANCES` 与 `--max-instances` 据预算设定
- [ ] PRIVACY.md 中之 xAPI 白名单与 lrs.py 中 `SAFE_RESULT_KEYS` 一致
- [ ] Corpus 已经权威校勘本（吴光等编《王阳明全集》）核校

---

## 文件清单

```
wwwd-backend/
├── server.py                  # FastAPI app + Cloud Run lifespan
├── rag.py                     # RAG retriever (GCS-backed)
├── prompts.py                 # 四阶提示链 + HAA preamble
├── auth.py                    # Google OAuth + 匿名 session 兜底
├── lrs.py                     # xAPI statements + Cloud Logging
├── gcs.py                     # GCS adapter (corpus + embeddings)
├── precompute_embeddings.py   # 一次性脚本：corpus → GCS
├── corpus.json                # 24 段示例语料 (待权威校订)
├── requirements.txt
├── Dockerfile                 # multi-stage; bakes embedding model
├── .dockerignore
├── cloudbuild.yaml            # CI/CD (build + push + deploy)
├── DEPLOYMENT.md              # 本文件
└── PRIVACY.md                 # 公开 xAPI 数据白名单
```
