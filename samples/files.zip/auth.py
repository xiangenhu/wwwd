"""
身份解析 · Google OAuth ID token 验证 + 匿名 session 兜底
========================================================

两种 actor 身份模式（皆为化名，永不存原始邮箱姓名）：

1. 已登录 · Authorization: Bearer <Google ID token>
   → actor.account.name = "google:" + sha256(salt + google_sub)[:32]

2. 匿名  · X-Wwwd-Session: <client-generated UUID>
   → actor.account.name = "anon:"   + sha256(salt + session_uuid)[:32]

WWWD_REQUIRE_AUTH=1 时，第 2 模式被拒（401）。默认允许匿名。
"""
import os
import hashlib
from typing import Optional

from fastapi import Header, HTTPException
from google.oauth2 import id_token
from google.auth.transport import requests as g_requests

GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_OAUTH_CLIENT_ID", "")
HASH_SALT = os.environ.get("WWWD_ACTOR_SALT", "wwwd-CHANGE-ME-via-Secret-Manager")
ACTOR_HOMEPAGE = os.environ.get("WWWD_ACTOR_HOMEPAGE", "https://wwwd.skoonline.org")
REQUIRE_AUTH = os.environ.get("WWWD_REQUIRE_AUTH", "0") == "1"


class Actor:
    def __init__(self, identity: str, source: str):
        self.identity = identity
        self.source = source  # "google" | "anon"

    def to_xapi(self) -> dict:
        return {
            "objectType": "Agent",
            "account": {
                "homePage": ACTOR_HOMEPAGE,
                "name": f"{self.source}:{self.identity}",
            },
        }


def _hash(s: str) -> str:
    return hashlib.sha256((HASH_SALT + s).encode("utf-8")).hexdigest()[:32]


async def get_actor(
    authorization: Optional[str] = Header(None),
    x_wwwd_session: Optional[str] = Header(None, alias="X-Wwwd-Session"),
) -> Actor:
    """FastAPI dependency: resolve an Actor from request headers."""

    # 1. Try Google OAuth
    if authorization and authorization.startswith("Bearer "):
        token = authorization[7:]
        if not GOOGLE_CLIENT_ID:
            if REQUIRE_AUTH:
                raise HTTPException(500, "OAuth not configured (GOOGLE_OAUTH_CLIENT_ID missing)")
            # else fall through
        else:
            try:
                info = id_token.verify_oauth2_token(
                    token, g_requests.Request(), GOOGLE_CLIENT_ID
                )
                return Actor(_hash(info["sub"]), source="google")
            except ValueError as e:
                if REQUIRE_AUTH:
                    raise HTTPException(401, f"Invalid Google ID token: {e}")
                # else fall through to anonymous

    # 2. Anonymous mode requires a session ID
    if REQUIRE_AUTH:
        raise HTTPException(401, "Authentication required (WWWD_REQUIRE_AUTH=1)")

    if x_wwwd_session:
        return Actor(_hash(x_wwwd_session), source="anon")

    # 3. No headers — ephemeral. Statements still emit but are not joinable.
    return Actor(_hash("ephemeral-no-headers"), source="anon")
