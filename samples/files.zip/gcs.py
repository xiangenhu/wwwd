"""
GCS 适配器 · 启动时拉取语料与预计算 embeddings 至本地 /tmp 缓存。
==========================================================
Cloud Run 之 /tmp 在内存中（非持久），但容器生命期内可写。
此适配器使每实例首请求延迟最小：约 100KB GCS 拉取，缓存命中后零网络。

GCS 布局：
  gs://{bucket}/corpus/{version}/corpus.json
  gs://{bucket}/corpus/{version}/embeddings.npy
  gs://{bucket}/corpus/{version}/manifest.json
"""
import os
import json
from pathlib import Path
from typing import Optional

import numpy as np
from google.cloud import storage

CACHE_DIR = Path(os.environ.get("WWWD_CACHE_DIR", "/tmp/wwwd-cache"))
CACHE_DIR.mkdir(parents=True, exist_ok=True)


class GCSCorpusLoader:
    def __init__(self, bucket_name: str, version: str = "v1"):
        self.bucket_name = bucket_name
        self.version = version
        self._client = storage.Client()
        self._bucket = self._client.bucket(bucket_name)

    def _fetch(self, blob_path: str) -> Optional[Path]:
        """Download a blob to local cache, return path. None if not found."""
        cache_path = CACHE_DIR / f"{self.version}_{Path(blob_path).name}"
        if cache_path.exists():
            return cache_path
        blob = self._bucket.blob(blob_path)
        if not blob.exists():
            return None
        blob.download_to_filename(str(cache_path))
        return cache_path

    def load_corpus(self) -> dict:
        path = self._fetch(f"corpus/{self.version}/corpus.json")
        if path is None:
            raise FileNotFoundError(
                f"corpus.json not found at gs://{self.bucket_name}/corpus/{self.version}/"
            )
        with open(path, encoding="utf-8") as f:
            return json.load(f)

    def load_embeddings(self) -> Optional[np.ndarray]:
        """Return precomputed embeddings, or None if not yet uploaded."""
        path = self._fetch(f"corpus/{self.version}/embeddings.npy")
        return np.load(str(path)) if path else None

    def load_manifest(self) -> dict:
        path = self._fetch(f"corpus/{self.version}/manifest.json")
        if path is None:
            return {}
        with open(path, encoding="utf-8") as f:
            return json.load(f)
