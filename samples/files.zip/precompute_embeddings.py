"""
预计算 embeddings 并上传至 GCS · 一次性脚本
============================================

何时跑：
  1. 初次部署前
  2. 每次 corpus.json 变更后（务必 bump --version）
  3. 切换 embedding 模型时

用法：
  pip install sentence-transformers google-cloud-storage numpy
  gcloud auth application-default login
  python precompute_embeddings.py \\
      --corpus corpus.json \\
      --bucket wwwd-corpus \\
      --version v1

成功后 Cloud Run 实例启动时只需拉取 embeddings.npy（~80KB / 24 段），
不再于运行时编码语料。冷启动从 ~30s 降至 ~8s。
"""
import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from sentence_transformers import SentenceTransformer
from google.cloud import storage


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", default="corpus.json")
    ap.add_argument("--bucket", required=True, help="GCS bucket name (no gs:// prefix)")
    ap.add_argument("--version", default="v1", help="Version tag · bump on corpus change")
    ap.add_argument("--model", default="BAAI/bge-small-zh-v1.5")
    args = ap.parse_args()

    corpus_path = Path(args.corpus)
    if not corpus_path.exists():
        print(f"✗ Corpus file not found: {corpus_path}", file=sys.stderr)
        sys.exit(1)

    print(f"[1/4] 读 {corpus_path}")
    with open(corpus_path, encoding="utf-8") as f:
        corpus = json.load(f)
    passages = corpus["passages"]
    print(f"      {len(passages)} 段")

    print(f"[2/4] 载模型 · {args.model}")
    model = SentenceTransformer(args.model)

    print(f"[3/4] 编码")
    embeddings = model.encode(
        [p["text"] for p in passages],
        normalize_embeddings=True,
        convert_to_numpy=True,
        show_progress_bar=True,
    )
    np.save("embeddings.npy", embeddings)
    print(f"      shape={embeddings.shape} dtype={embeddings.dtype}")

    print(f"[4/4] 上传 · gs://{args.bucket}/corpus/{args.version}/")
    client = storage.Client()
    bucket = client.bucket(args.bucket)
    if not bucket.exists():
        print(f"✗ Bucket gs://{args.bucket} 不存在。先 `gsutil mb gs://{args.bucket}`", file=sys.stderr)
        sys.exit(1)

    prefix = f"corpus/{args.version}"
    for src, dst in [
        ("embeddings.npy", f"{prefix}/embeddings.npy"),
        (str(corpus_path), f"{prefix}/corpus.json"),
    ]:
        blob = bucket.blob(dst)
        blob.upload_from_filename(src)
        print(f"      ✓ {dst}")

    manifest = {
        "version": args.version,
        "model": args.model,
        "embedding_dim": int(embeddings.shape[1]),
        "passage_count": len(passages),
        "created_at": datetime.now(timezone.utc).isoformat(),
        "warning": corpus.get("_meta", {}).get("warning", ""),
    }
    bucket.blob(f"{prefix}/manifest.json").upload_from_string(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        content_type="application/json",
    )
    print(f"      ✓ manifest.json")
    print()
    print("成。Cloud Run 部署时设：")
    print(f"  WWWD_GCS_BUCKET={args.bucket}")
    print(f"  WWWD_CORPUS_VERSION={args.version}")


if __name__ == "__main__":
    main()
