#!/usr/bin/env bash
# Self-contained installer for Claude Code team skills.
#
# Usage:
#   ./install.sh                  # install into ./.claude/commands/ (current dir)
#   ./install.sh --force          # overwrite existing files without prompting
#   ./install.sh --target <dir>   # install into <dir>/.claude/commands/
#   ./install.sh --user           # install into ~/.claude/commands/ (available in every project)
#   ./install.sh --list           # list skills in this package and exit
#
# This script is shipped inside claude-team-skills.zip alongside team-*.md files.
# After unzipping, run it from the extracted directory.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

FORCE=false
TARGET_DIR="$PWD"
USER_INSTALL=false
LIST_ONLY=false

while [ $# -gt 0 ]; do
  case "$1" in
    --force) FORCE=true; shift ;;
    --target) TARGET_DIR="$2"; shift 2 ;;
    --user) USER_INSTALL=true; shift ;;
    --list) LIST_ONLY=true; shift ;;
    -h|--help)
      sed -n '2,13p' "$0" | sed 's/^# \{0,1\}//'
      exit 0
      ;;
    *)
      echo "Unknown option: $1" >&2
      echo "Run '$0 --help' for usage." >&2
      exit 1
      ;;
  esac
done

# Collect team skill files shipped alongside this script
SKILL_FILES=()
for f in "$SCRIPT_DIR"/team-*.md; do
  [ -f "$f" ] && SKILL_FILES+=("$f")
done

if [ ${#SKILL_FILES[@]} -eq 0 ]; then
  echo "Error: no team-*.md files found next to install.sh" >&2
  echo "Expected location: $SCRIPT_DIR" >&2
  exit 1
fi

if [ "$LIST_ONLY" = true ]; then
  echo "Skills in this package:"
  for f in "${SKILL_FILES[@]}"; do
    echo "  - $(basename "$f" .md)"
  done
  if [ -f "$SCRIPT_DIR/manifest.json" ]; then
    echo
    echo "Manifest:"
    cat "$SCRIPT_DIR/manifest.json"
  fi
  exit 0
fi

# Resolve destination
if [ "$USER_INSTALL" = true ]; then
  COMMANDS_DIR="$HOME/.claude/commands"
else
  if [ ! -d "$TARGET_DIR" ]; then
    echo "Error: target directory does not exist: $TARGET_DIR" >&2
    exit 1
  fi
  COMMANDS_DIR="$TARGET_DIR/.claude/commands"
fi

mkdir -p "$COMMANDS_DIR"

echo "Installing ${#SKILL_FILES[@]} team skills into: $COMMANDS_DIR"
echo

INSTALLED=0
SKIPPED=0
OVERWRITTEN=0

for f in "${SKILL_FILES[@]}"; do
  BASENAME=$(basename "$f")
  TARGET="$COMMANDS_DIR/$BASENAME"

  if [ -f "$TARGET" ]; then
    if [ "$FORCE" = true ]; then
      cp "$f" "$TARGET"
      echo "  Overwritten: $BASENAME"
      OVERWRITTEN=$((OVERWRITTEN + 1))
      continue
    fi

    # Prompt only if we have an interactive terminal
    if [ -t 0 ]; then
      read -rp "  Overwrite existing $BASENAME? [y/N] " answer
      if [[ ! "$answer" =~ ^[Yy] ]]; then
        echo "    Skipped: $BASENAME"
        SKIPPED=$((SKIPPED + 1))
        continue
      fi
      cp "$f" "$TARGET"
      echo "    Overwritten: $BASENAME"
      OVERWRITTEN=$((OVERWRITTEN + 1))
      continue
    else
      echo "  Skipped (exists, non-interactive): $BASENAME"
      SKIPPED=$((SKIPPED + 1))
      continue
    fi
  fi

  cp "$f" "$TARGET"
  echo "  Installed: $BASENAME"
  INSTALLED=$((INSTALLED + 1))
done

echo
echo "Done: $INSTALLED new, $OVERWRITTEN overwritten, $SKIPPED skipped"
echo "Skills are in: $COMMANDS_DIR/"
echo
echo "Invoke them in Claude Code with:"
for f in "${SKILL_FILES[@]}"; do
  NAME=$(basename "$f" .md)
  echo "  /$NAME"
done
